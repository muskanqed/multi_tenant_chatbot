import React from "react";

const ChatLayout = ({ children }: any) => {
  return <div>{children}</div>;
};

export default ChatLayout;
