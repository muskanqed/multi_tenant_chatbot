import React from 'react'

const RegisterPage = () => {
  return (
    <div>

    </div>
  )
}

export default RegisterPage
