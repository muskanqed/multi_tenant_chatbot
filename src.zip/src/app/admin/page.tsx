import React from 'react'

const AdminPage = () => {
  return (
    <div>

    </div>
  )
}

export default AdminPage
